//OpenGL stuff
#define GLEW_STATIC
#include <GL/glew.h>
#include <GLFW/glfw3.h>

//Memory leak detection
#define _CRTDBG_MAP_ALLOC  
#include <stdlib.h>  
#include <crtdbg.h>  

#include "shader.h"

#ifdef _DEBUG
#include <iostream>
#endif

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include "Mesh.h"

int main()
{
    {
        //init GLFW
        {
            if (glfwInit() == GLFW_FALSE)
            {
#ifdef _DEBUG
                std::cout << "GLFW failed to initialize" << std::endl;
#endif
                std::cin.get();
                _CrtDumpMemoryLeaks();
                return 1;
                //no need to call glfwTerminate() here because init never happened
            }
        }

        //create & init window, set viewport
        int width = 800;
        int height = 600;
        GLFWwindow* window = glfwCreateWindow(width, height, "Shapes Moving", nullptr, nullptr);
        {
            if (window == nullptr)
            {
#ifdef _DEBUG
                std::cout << "GLFW failed to create window" << std::endl;
#endif
                glfwTerminate();
                _CrtDumpMemoryLeaks();
                return 1;
            }

            //tells OpenGL to use this window for this thread
            //(this would be more important for multi-threaded apps)
            glfwMakeContextCurrent(window);

            //gets the width & height of the window and specify it to the viewport
            int windowWidth, windowHeight;
            glfwGetFramebufferSize(window, &windowWidth, &windowHeight);
            glViewport(0, 0, windowWidth, windowHeight);
        }

        //init GLEW
        {
            if (glewInit() != GLEW_OK)
            {
#ifdef _DEBUG
                std::cout << "GLEW failed to initialize" << std::endl;
#endif
                glfwTerminate();
                std::cin.get();
                _CrtDumpMemoryLeaks();
                return 1;
            }
        }

        //init the shader program
        GLuint shaderProgram = glCreateProgram();

        //create vS and attach to shader program
        Shader *vs = new Shader();
        vs->InitFromFile("assets/shaders/vertexShader.glsl", GL_VERTEX_SHADER);
        glAttachShader(shaderProgram, vs->GetShaderLoc());

        //create FS and attach to shader program
        Shader *fs = new Shader();
        fs->InitFromFile("assets/shaders/fragmentShader.glsl", GL_FRAGMENT_SHADER);
        glAttachShader(shaderProgram, fs->GetShaderLoc());

        //link everything that's attached together
        glLinkProgram(shaderProgram);	//can also call get programiv to see if linking failed

        //everything's in the program, we don't need this
        delete fs;
        delete vs;

        //init the mesh
		//Rectangle vertices
		GLfloat verticesSquare[] = {
			1.0f, 0.5f, 0.0f,
			-1.0f,-1.0f, 0.0f,
			-1.0f, 0.5f, 0.0f,
			1.0f, 0.5f, 0.0f,
			1.0f,-1.0f, 0.0f,
			-1.0f,-1.0f, 0.0f
		};

		for (int i = 0; i < _countof(verticesSquare); i++)
		{
			verticesSquare[i] += 1.5f;
		}

		// Triangle Vertices
		GLfloat verticesTriangle[] = {
			1.0f, 0.5f, 0.0f,
			0.0f, -1.0f, 0.0f,
			0.0f, 0.5f, 0.0f
		};

		for (int i = 0; i < _countof(verticesTriangle); i++)
		{
			verticesTriangle[i] -= 3.0f;
		}

		/*
		GLfloat verticesCircle[] = {
			0.0f, 0.0f, 0.0f
		};
		int triAmnt = 5;
		GLfloat radius = 1.0f;
		int count = 3;

		for (int i = 0; i < triAmnt; i++)
		{
			if (i == 0)
			{
				verticesCircle[count] = 0.0f;
				verticesCircle[count+1] = radius * cos(i * (2.0f * glm::pi<float>() / triAmnt));
				verticesCircle[count+2] = radius * sin(i * (2.0f * glm::pi<float>() / triAmnt));
				count += 3;
			}

			else
			{
				verticesCircle[count] = 0.0f;
				verticesCircle[count+1] = radius * cos(i * (2.0f * glm::pi<float>() / triAmnt));
				verticesCircle[count+2] = radius * sin(i * (2.0f * glm::pi<float>() / triAmnt));
				count += 3;
			}
		}
		*/

		GLfloat verticesCircle[1080];
		GLfloat angle = 0;
		GLfloat radians = 0;
		
		for (int i = 0; i < 1080; i++)
		{
			if (i % 9 == 0)
			{
				verticesCircle[i] = cos(radians);
			}

			if (i % 9 == 1)
			{
				verticesCircle[i] = sin(radians);
			}

			if (i % 9 == 2)
			{
				verticesCircle[i] = 0.0f;
			}

			if (i % 9 == 3)
			{
				verticesCircle[i] = 0.0f;
			}

			if (i % 9 == 4)
			{
				verticesCircle[i] = 0.0f;
			}

			if (i % 9 == 5)
			{
				verticesCircle[i] = 0.0f;

				angle += 1;
				radians += (angle) * (glm::pi<float>() / 180);
			}

			if (i % 9 == 6)
			{
				verticesCircle[i] = cos(radians);
			}

			if (i % 9 == 7)
			{
				verticesCircle[i] = sin(radians);
			}

			if (i % 9 == 8)
			{
				verticesCircle[i] = 0.0f;
			}
		}

		for (int i = 0; i < 1080; i++)
		{
			verticesCircle[i] -= 0.5f;
		}
		
		Mesh* squareMesh = new Mesh();
		squareMesh->InitWithVertexArray(verticesSquare, _countof(verticesSquare), shaderProgram);

		Mesh* triangleMesh = new Mesh();
		triangleMesh->InitWithVertexArray(verticesTriangle, _countof(verticesTriangle), shaderProgram);

		Mesh* circleMesh = new Mesh();
		circleMesh->InitWithVertexArray(verticesCircle, _countof(verticesCircle), shaderProgram);

		glm::vec3 positionSquare = glm::vec3(0, 0, 0);
		glm::vec3 positionTriangle = glm::vec3(0, 0, 0);
		glm::mat4 modelToWorld;
		
		glEnable(GL_DEPTH_TEST);
		glDepthFunc(GL_LESS);

        //main loop
        while (!glfwWindowShouldClose(window))
        {
            //Input
            {
                //checks events to see if there are pending input
                glfwPollEvents();

                //breaks out of the loop if user presses ESC
                if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
                {
                    break;
                }
            }

            //Gameplay update
			modelToWorld = glm::translate(
				glm::identity<glm::mat4>(),
				positionSquare
			);

			positionSquare.x += 0.05f;
			//cout << positionSquare.x << " " << endl;
			if (positionSquare.x > 5.5f)
			{
				positionSquare.x = -5.5f;
			}

			positionSquare.y += 0.03f;
			//cout << positionSquare.x << " " << endl;
			if (positionSquare.y > 4.5f)
			{
				positionSquare.y = -4.5f;
			}

			modelToWorld = glm::translate(
				glm::identity<glm::mat4>(),
				positionTriangle
			);

			positionTriangle.x -= 0.03f;
			//cout << positionSquare.x << " " << endl;
			if (positionTriangle.x < -5.5f)
			{
				positionTriangle.x = 5.5f;
			}

            //Preparing to Render
            {
                //start off with clearing the 'color buffer'
                glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

                //clear the window to have c o r n f l o w e r   b l u e
                glClearColor(0.392f, 0.584f, 0.929f, 1.0f);
            }

            //enable shader
            glUseProgram(shaderProgram);

			glm::mat4 view = glm::lookAtLH(
				glm::vec3(0.0f, 0.0f, 5.f),
				glm::vec3(0.0f, 0.0f, -4.0f),
				glm::vec3(0.0f, 1.f, 0.0f)
			);

			glm::mat4 projection = glm::perspectiveFovLH<GLfloat>(
				60.0f * glm::pi<float>() / 180.0f,
				(float)width,
				(float)height,
				0.01f,
				100.f
			);

			GLuint viewMatLoc = glGetUniformLocation(
				shaderProgram,
				"viewMatrix"
			);
			glUniformMatrix4fv(
				viewMatLoc,
				1,
				GL_FALSE,
				&(view[0][0])
			);

			GLuint projectionMatLoc = glGetUniformLocation(
				shaderProgram,
				"projectionMatrix"
			);
			glUniformMatrix4fv(
				projectionMatLoc,
				1,
				GL_FALSE,
				&(projection[0][0])
			);

			GLuint modelToWorldLoc = glGetUniformLocation(
				shaderProgram,
				"modelToWorld"
			);
			glUniformMatrix4fv(
				modelToWorldLoc,
				1,
				GL_FALSE,
				&(modelToWorld[0][0])
			);

			squareMesh->Render();
			triangleMesh->Render();
			circleMesh->Render();

            //'clear' for next draw call
            glBindVertexArray(0);
            glUseProgram(0); 

            //Clean-up after Render
            {
                //swaps the front buffer with the back buffer
                glfwSwapBuffers(window);
            }

        }
		delete squareMesh;
		delete triangleMesh;
		delete circleMesh;
    }

    //clean up
    glfwTerminate();
    _CrtDumpMemoryLeaks();
    return 0;
}

// old code

/*
GLfloat verticesCircle[1080];
GLfloat radius = 1;
int triangleAmount = 1080;
//int i = 0;
//int count = 0;

// loop for number of subdivisions
for (int i = 0; i < triangleAmount; i++)
{
/*
// create points
glm::vec3 pointA = glm::vec3(radius * cos((2.0f * PI) * i / (float)subdivisions), radius * sin((2.0f * PI) * i / (float)subdivisions), 0);
glm::vec3 pointB = glm::vec3(radius * cos((2.0f * PI) * (i + 1) / (float)subdivisions), radius*sin((2.0f * PI) * (i + 1) / (float)subdivisions), 0);
glm::vec3 pointC = glm::vec3(0, 0, 0);

cout << count << endl;
// add tri to the mesh
if (i == 0)
{
verticesCircle[count]  << endl = pointA.x;
count++;
verticesCircle[count]  << endl = pointA.y;
count++;
verticesCircle[count]  << endl = pointA.z;
count++;

verticesCircle[count]  << endl = pointB.x;
count++;
verticesCircle[count]  << endl = pointB.y;
count++;
verticesCircle[count]  << endl = pointB.z;
count++;

verticesCircle[count]  << endl = pointC.x;
count++;
verticesCircle[count]  << endl = pointC.y;
count++;
verticesCircle[count]  << endl = pointC.z;
count++;
}
else
{
verticesCircle[count]  << endl = pointA.x;
count++;
verticesCircle[count]  << endl = pointA.y;
count++;
verticesCircle[count]  << endl = pointA.z;
count++;

verticesCircle[count]  << endl = pointB.x;
count++;
verticesCircle[count]  << endl = pointB.y;
count++;
verticesCircle[count]  << endl = pointB.z;
count++;

verticesCircle[count]  << endl = pointC.x;
count++;
verticesCircle[count]  << endl = pointC.y;
count++;
verticesCircle[count]  << endl = pointC.z;
count++;
}
*/
/*
if (i == 0)
{
verticesCircle[0] = (GLfloat)(radius * cos(i * (glm::pi<float>() * 2.0f) / triangleAmount));
cout << verticesCircle[count]  << endl;
count++;
verticesCircle[count] = (GLfloat)(radius * sin(i * (glm::pi<float>() * 2.0f) / triangleAmount));
cout << verticesCircle[count]  << endl;
count++;
verticesCircle[count] = 0.0f;
cout << verticesCircle[count]  << endl;
count++;
}

else
{
verticesCircle[count] = (GLfloat)(radius * cos(i * (glm::pi<float>() * 2.0f) / triangleAmount));
cout << verticesCircle[count]  << endl;
count++;
verticesCircle[count] = (GLfloat)(radius * sin(i * (glm::pi<float>() * 2.0f) / triangleAmount));
cout << verticesCircle[count]  << endl;
count++;
verticesCircle[count] = 0.0f;
cout << verticesCircle[count]  << endl;
count++;
}
*/
/*
if (i % 3 == 0)
{
verticesCircle[i] = (GLfloat)(radius * cos(i * (glm::pi<float>() * 2.0f) / triangleAmount));
}

if (i % 3 == 1)
{
verticesCircle[i] = (GLfloat)(radius * sin(i * (glm::pi<float>() * 2.0f) / triangleAmount));

}

if (i % 3 == 2)
{
verticesCircle[i] = 0.0f;
}
}
*/